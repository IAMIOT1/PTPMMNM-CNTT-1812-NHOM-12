<?php
// Mỗi phần tử là một gói ngôn ngữ của phần mềm.
// total: tổng số chuỗi cần dịch; translated: số chuỗi đã dịch (dữ liệu giả lập).
return [
 ['id'=>1, 'title'=>'Vietnamese Web Pack', 'language'=>'vi', 'platform'=>'web', 'total'=>10, 'translated'=>9],
 ['id'=>2, 'title'=>'Japanese Mobile Pack', 'language'=>'ja', 'platform'=>'mobile', 'total'=>5, 'translated'=>5],
 ['id'=>3, 'title'=>'French Web Pack', 'language'=>'fr', 'platform'=>'web', 'total'=>20, 'translated'=>2],
];
