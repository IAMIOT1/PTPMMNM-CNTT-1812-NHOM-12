<?php
declare(strict_types=1);

/**
 * Lọc danh sách gói ngôn ngữ bằng AND:
 * - $query: từ khóa trong tên gói (rỗng = không lọc)
 * - $platform: nền tảng web/mobile (rỗng = không lọc)
 * - $incompleteOnly: true = chỉ lấy gói còn chuỗi chưa dịch
 * Chỉ trả dữ liệu, không in HTML, không sửa mảng đầu vào.
 */
function filterPacks(array $packs, string $query, string $platform = '',
    bool $incompleteOnly = false): array
{
    $result = [];
    foreach ($packs as $pack) {
        $matchQuery = $query === ''
            || stripos($pack['title'], $query) !== false;
        $matchPlatform = $platform === ''
            || strcasecmp($pack['platform'], $platform) === 0;
        $matchIncomplete = !$incompleteOnly
            || ($pack['total'] - $pack['translated']) > 0;
        if ($matchQuery && $matchPlatform && $matchIncomplete) {
            $result[] = $pack;
        }
    }
    return $result;
}

function missingStrings(array $pack): int
{
    return max(0, $pack['total'] - $pack['translated']);
}

function progressPercent(array $pack): int
{
    return $pack['total'] > 0
        ? (int)floor($pack['translated'] * 100 / $pack['total'])
        : 0;
}
