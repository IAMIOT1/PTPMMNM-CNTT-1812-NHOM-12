<?php
declare(strict_types=1);

function field(array $input, string $key): string {
    $value = $input[$key] ?? '';
    return is_string($value) ? trim($value) : '';
}

function e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Kiểm tra form gửi đề xuất bản dịch ở phía máy chủ.
 * Trả về ['errors' => [mã lỗi...], 'data' => dữ liệu đã xử lý].
 */
function validateContribution(array $input, array $packs): array {
    $packId = filter_var(field($input, 'pack_id'), FILTER_VALIDATE_INT);
    $name = field($input, 'name');
    $email = strtolower(field($input, 'email')); // Quy ước của bài: email chữ thường.
    $text = field($input, 'text');
    $errors = [];
    if ($packId === false || !in_array($packId, array_column($packs, 'id'), true)) {
        $errors[] = 'PACK_INVALID';
    }
    if ($name === '' || strlen($name) > 120 || str_contains($name, "\0")) {
        $errors[] = 'NAME_INVALID';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 200) {
        $errors[] = 'EMAIL_INVALID';
    }
    // strlen tính theo byte, không phải số ký tự tiếng Việt.
    if ($text === '' || strlen($text) > 1000 || str_contains($text, "\0")) {
        $errors[] = 'TEXT_INVALID';
    }
    return ['errors'=>$errors, 'data'=>[
        'pack_id'=>(int)$packId, 'name'=>$name, 'email'=>$email, 'text'=>$text
    ]];
}
