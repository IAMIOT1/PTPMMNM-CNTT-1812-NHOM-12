<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LangPack Manager • Bài thực hành OSS</title>
<link rel="stylesheet" href="/assets/css/tokens.css">
<link rel="stylesheet" href="/assets/css/app.css">
</head>
<body>
<a class="skip-link" href="#main">Đến nội dung chính</a>
<header class="site-header">
<div class="header-inner">
<strong class="brand">LangPack Manager</strong>
<p>Quản lý bản dịch và phát hành gói ngôn ngữ cho phần mềm</p>
</div>
</header>
<main id="main" tabindex="-1">
<nav class="main-nav" aria-label="Điều hướng chính">
<a href="/">Danh sách gói ngôn ngữ</a>
<a href="/contribute.php">Gửi đề xuất bản dịch</a>
</nav>
